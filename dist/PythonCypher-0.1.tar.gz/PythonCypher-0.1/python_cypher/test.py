class Class(object):
    def __init__(self):
        import networkx as nx
        self.g = nx.Graph()
